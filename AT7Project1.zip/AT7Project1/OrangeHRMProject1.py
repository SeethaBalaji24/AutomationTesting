from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Firefox()

# TC_Login_01

class tc_login_01:
    driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login")
    driver.implicitly_wait(10)
    driver.find_element(By.XPATH, "//input[@name='username']").send_keys("Admin")
    driver.find_element(By.XPATH, "//input[@name='password']").send_keys("admin123")
    # Validate Homepage after login
    driver.find_element(By.XPATH, "//h6[text()='Dashboard']")
    driver.close()


# TC_Login_02

class tc_login_02:
    driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login")
    driver.implicitly_wait(10)
    driver.find_element(By.XPATH, "//input[@name='username']").send_keys("Admin")
    driver.find_element(By.XPATH, "//input[@name='password']").send_keys("incorrectpass")
    # Validate Incorrect Login
    driver.find_element(By.XPATH, "//p[text()='Invalid credentials']")
    driver.close()


# TC_PIM_01

class tc_pim_01:
    driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login")
    driver.implicitly_wait(10)
    driver.find_element(By.XPATH, "//input[@name='username']").send_keys("Admin")
    driver.find_element(By.XPATH, "//input[@name='password']").send_keys("admin123")
    driver.find_element(By.XPATH, "//span[text()='PIM']").click()
    driver.find_element(By.XPATH, "//a[text()='Add Employee']").click()
    driver.find_element(By.NAME, "firstName").send_keys("Seetha")
    driver.find_element(By.NAME, "lastName").send_keys("Balaji")
    driver.find_element(By.XPATH, "//i[@class='oxd-icon bi-plus']").send_keys("c:/images/profilepic.jpg")
    driver.find_element(By.XPATH, "//button[text()=' Save ']").click()
    driver.close()


# TC_PIM_02

class tc_pim_02:
    driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login")
    driver.implicitly_wait(10)
    driver.find_element(By.XPATH, "//input[@name='username']").send_keys("Admin")
    driver.find_element(By.XPATH, "//input[@name='password']").send_keys("admin123")
    driver.find_element(By.XPATH, "//span[text()='PIM']").click()
    driver.find_element(By.XPATH, "//a[text()='Edit Employee']").click()
    driver.find_element(By.NAME, "firstName").send_keys("Ctha")
    driver.find_element(By.XPATH, "//button[text()=' Save ']").click()
    driver.close()


# TC_PIM_03

class tc_pim_03:
    driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login")
    driver.implicitly_wait(10)
    driver.find_element(By.XPATH, "//input[@name='username']").send_keys("Admin")
    driver.find_element(By.XPATH, "//input[@name='password']").send_keys("admin123")
    driver.find_element(By.XPATH, "//span[text()='PIM']").click()
    driver.find_element(By.XPATH, "//i[@class='oxd-icon bi-trash']").click()
    driver.find_element(By.XPATH, "//button[text()=' Yes, Delete ']").click()
    driver.close()
